<?php

// environment variables
$db_name = 'my_app';
$user = 'root';
$user_pass = 'fe-angular';
$table1 = 'restaurants';

?>